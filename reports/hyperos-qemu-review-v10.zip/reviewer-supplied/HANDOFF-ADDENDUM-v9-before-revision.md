# ADDENDUM untuk HANDOFF-HyperOS-QEMU (status 2026-11-05)

Dibaca bersama handoff utama. Isi di sini hasil verifikasi ulang terhadap log mentah v6-v8 di `hyperos-qemu-review-v9.zip`. Jika bertentangan dengan handoff utama, addendum ini yang berlaku.

Catatan peran: penulis addendum ini hanya punya ZIP teks. Firmware 8,7 GB dan QEMU tidak ada di sana, jadi Tugas A dan Tugas B BELUM dikerjakan. Yang sudah dikerjakan hanya analisis ulang dan persiapan.

## 1. Koreksi atas handoff utama

1. **Bagian 6C, "restorecon sudah dibuktikan berjalan di v8", belum terbukti.** Yang terbukti: denial `unlabeled` pada `ino=3` berhenti (v8: 11 baris, 99.94-103.95 s) tepat di sekitar post-fs-data. Itu indikasi dari urutan waktu. Log tidak memuat baris `Command 'restorecon /data' ... succeeded`.
2. **Cek newline file asli sudah diulang dan lolos.** Byte terakhir `vendor_file_contexts.original` = `0a` (dan manifest v8 mencatat `vendor_contexts_original_ends_newline`). Dugaan "baris menempel" gugur.
3. **v8 sebenarnya sudah memuat penangkap logcat**, bukan hanya `setprop`. `init.target.rc.v8-patched` (sekitar baris 677-690) berisi `setprop ...no_fatal` (ditolak SELinux), `restorecon_recursive /data`, dan `service qemu-logcat` yang distart dari `on post-fs-data`. Handoff utama (bagian 4) hanya menyebut setprop.

## 2. Temuan baru dari log mentah

### 2.1 Perkiraan waktu abort keystore2
Setiap abort memicu `crash_dump64` yang ditolak ptrace (`bug=b/376065666`). Stempel audit itu jatuh sesaat setelah abort, jadi lebih dekat ke waktu abort sebenarnya daripada baris init "received signal 6" (tertunda karena init diblokir `mount_all --late`).

v8 (start -> perkiraan abort dari stempel audit):

| pid | start | perkiraan abort | umur | keadaan saat abort |
|---|---|---|---|---|
| 330 | 78.76 | ~88.0 | ~9 s | /data belum ter-mount (mount selesai 99.26) |
| 392 | 100.05 | ~106.2 | ~6 s | /data ter-mount, tetapi `/data/misc/keystore` belum ada (mkdir baru 106.41) |
| 433 | 107.33 | ~112.7 | ~5.4 s | direktori sudah ada |
| 458 | 113.40 | ~117.7 | ~4.3 s | direktori sudah ada |
| 496 | 122.03 | ~127.1 | ~5.1 s | direktori sudah ada |

Pembacaan hati-hati (inferensi stempel waktu, BUKAN pesan panic):
- Dua abort pertama terjadi sebelum direktori kerja keystore2 (`/data/misc/keystore`, lihat `keystore2.rc`) ada. Itu bisa menjelaskan dua instance itu saja.
- Tiga instance terakhir hidup 4-5,5 s dengan direktori sudah ada, lalu tetap abort. Pola umur seragam lebih cocok dengan penantian/timeout daripada kegagalan file langsung. Ini menambah bobot H2 tetapi bukan bukti.
- Angka "~5 s timeout" tidak diverifikasi ke source keystore2 Android 16. Jangan dijadikan fakta.
- Catatan: keystore2 distart di 78.76 saat /data belum ada. Itu urutan bawaan `class early_hal`, bukan bug patch.

### 2.2 Kenapa penangkap logcat v8 tidak menghasilkan apa pun
Tidak ada baris `starting service 'qemu-logcat'` dan tidak ada `Command 'restorecon_recursive /data' action=post-fs-data (...init.target.rc...)` di log v8. Perintah post-fs-data terakhir yang tercatat adalah `vdc keymaster earlyBootEnded` (106.87, init.rc:906); sesudahnya tidak ada perintah post-fs-data tercatat sampai reboot paksa (~131 s). Blok vendor diantre setelah blok `init.rc:847`, jadi kemungkinan tidak sempat jalan. Itu dugaan; yang pasti hanya baris `start qemu-logcat` tidak ada.

Sebaliknya aksi `on init` milik vendor TERBUKTI jalan (`processing action (init) from (init.target.rc:677)` di 56.79 s). `logd` hidup sejak 52.38 s, jauh sebelum keystore2 (78.76 s).

### 2.3 Implikasi untuk v9 (usulan, belum teruji)
Pindahkan penangkap logcat dari `on post-fs-data` ke `on init`:

```
# QEMU-only: tangkap log lebih awal, tanpa menyentuh SELinux/AVB
on init
    start qemu-logcat

service qemu-logcat /system/bin/logcat -b all -v threadtime
    class late_start
    user root
    group log
    console
    disabled
    oneshot
```
- Hapus `setprop init.svc_debug.no_fatal...` (terbukti ditolak) dan `restorecon_recursive /data` (stok sudah menjalankannya).
- Opsi `console` dipertahankan dari v8 (belum terbukti berfungsi). Jika output tidak muncul di serial, catat apa adanya. Cadangan: `exec_background ... sh -c "... > /dev/kmsg"`, tetapi domain hasil transisi `sh` dari init tidak diketahui; coba satu per satu.
- Jika domain service ditolak policy, salin baris avc persisnya ke NOTES.md sebagai data. Jangan melonggarkan policy.
- Satu perubahan, satu hipotesis ("logcat bisa ditangkap lewat jalur `on init`"), maksimal 2 percobaan.

## 3. Yang masih belum diketahui (jangan diklaim)
- Pesan panic keystore2 (H1 vs H2) belum ditangkap.
- Apakah `vendor.keymint-qti` (pid 274) menunggu TrustZone: tidak ada baris yang menyatakan itu langsung.
- Di mana `IKeyMintDevice/default`, `IBootControl/default`, `IQSEECom/default` dideklarasikan. Manifest yang sudah diekstrak tidak memuatnya (dicek ulang dengan grep di `extracted/vendor/etc`; hanya `vendor_file_contexts` menyebut qseecom). Perlu Tugas A.
- Apakah `ro.vendor.qti.soc_name` yang kosong mempengaruhi pemuatan manifest.

## 4. Tugas A
Skrip `extract_task_a.py` hanya MENDETEKSI tipe filesystem (magic bytes); ekstraksi berkas dilakukan pelaksana dengan alat yang cocok. Berkas target: `/vendor/etc/vintf/manifest.xml`, seluruh `/vendor/etc/vintf/manifest/`, `/odm/etc/vintf/*`, `/vendor/bin/init.qti.qcv.sh`, `/vendor/etc/init/qseecomd.rc`, `/vendor/etc/init/init.qti.qcv.rc`. Magic yang relevan: EROFS `0xE0F5E1E2` di offset 1024, ext4 `0xEF53` di offset 1080, F2FS `0xF2F52010` di offset 1024, sparse `0xED26FF3A` di offset 0 (perlu `simg2img` dulu).

## 5. Urutan kerja
1. Tugas A, kirim ZIP < 25 MB.
2. v9 = penangkap logcat di `on init` (bagian 2.3), log mentah disimpan.
3. Setelah pesan panic ada, baru Tugas C. Batas keselamatan dan kriteria berhenti di handoff utama tidak berubah.
