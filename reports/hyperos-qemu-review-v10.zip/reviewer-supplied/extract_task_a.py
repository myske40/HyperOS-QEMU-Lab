#!/usr/bin/env python3
"""Tugas A (bagian deteksi): tentukan tipe filesystem image, baca-saja.

Pakai: python extract_task_a.py <image> [<image> ...]
Skrip ini HANYA mendeteksi tipe (magic bytes). Ekstraksi berkasnya dilakukan
AI pelaksana dengan alat yang cocok (erofs-utils, debugfs, dump.f2fs, simg2img),
sesuai daftar di HANDOFF-ADDENDUM-v9.md bagian 4. Tidak mengubah image.
"""
import sys

MAGICS = [
    ("sparse (jalankan simg2img dulu)", 0, bytes.fromhex("3aff26ed")),
    ("erofs", 1024, bytes.fromhex("e2e1f5e0")),
    ("f2fs", 1024, bytes.fromhex("1020f5f2")),
    ("ext4", 1080, bytes.fromhex("53ef")),
]

for path in sys.argv[1:]:
    with open(path, "rb") as f:
        hits = []
        for name, off, magic in MAGICS:
            f.seek(off)
            if f.read(len(magic)) == magic:
                hits.append(name)
        f.seek(0)
        head = f.read(16).hex()
    print(path, "->", hits or "TIDAK DIKENALI", "| 16 byte awal:", head)
