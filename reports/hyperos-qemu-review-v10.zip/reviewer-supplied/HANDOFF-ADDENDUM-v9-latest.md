# ADDENDUM untuk HANDOFF-HyperOS-QEMU (status 2026-11-05)

Dibaca bersama handoff utama. Isi di sini hasil verifikasi ulang terhadap log mentah v6-v8 di `hyperos-qemu-review-v9.zip`. Jika bertentangan dengan handoff utama, addendum ini yang berlaku.

Catatan peran: penulis addendum ini hanya punya ZIP teks. Firmware 8,7 GB dan QEMU tidak ada di sana, jadi Tugas A dan Tugas B BELUM dikerjakan. Yang sudah dikerjakan hanya analisis ulang dan persiapan.

## 1. Koreksi atas handoff utama

1. **Bagian 6C, "restorecon sudah dibuktikan berjalan di v8", belum terbukti.** Yang terbukti: denial `unlabeled` pada `ino=3` berhenti (v8: 11 baris, 99.94-103.95 s) tepat di sekitar post-fs-data. Itu indikasi dari urutan waktu. Log tidak memuat baris `Command 'restorecon /data' ... succeeded`.
2. **Cek newline file asli sudah diulang dan lolos.** Byte terakhir `vendor_file_contexts.original` = `0a` (dan manifest v8 mencatat `vendor_contexts_original_ends_newline`). Dugaan "baris menempel" gugur.
3. **v8 sebenarnya sudah memuat penangkap logcat**, bukan hanya `setprop`. `init.target.rc.v8-patched` (sekitar baris 677-690) berisi `setprop ...no_fatal` (ditolak SELinux), `restorecon_recursive /data`, dan `service qemu-logcat` yang distart dari `on post-fs-data`. Handoff utama (bagian 4) hanya menyebut setprop. Penangkap itu tidak pernah jalan; alasannya di bagian 2.2.
4. **"vdc keymaster earlyBootEnded sukses" keliru** (bagian 2.2). "succeeded" hanya spawn; vdc itu tidak selesai sebelum reboot paksa di v6 maupun v8.

## 2. Temuan baru dari log mentah

### 2.1 Perkiraan waktu abort keystore2
Setiap abort memicu `crash_dump64` yang ditolak ptrace (`bug=b/376065666`). Stempel audit itu jatuh sesaat setelah abort, jadi lebih dekat ke waktu abort sebenarnya daripada baris init "received signal 6" (tertunda karena init diblokir `mount_all --late`).

v8 (start -> perkiraan abort dari stempel audit):

| pid | start | perkiraan abort | umur | keadaan saat abort |
|---|---|---|---|---|
| 330 | 78.76 | ~88.0 | ~9 s | /data belum ter-mount (mount selesai 99.26) |
| 392 | 100.05 | ~106.2 | ~6 s | /data ter-mount, tetapi `/data/misc/keystore` belum ada (mkdir baru 106.41) |
| 433 | 107.33 | ~112.7 | ~5.4 s | direktori sudah ada |
| 458 | 113.40 | ~117.7 | ~4.3 s | direktori sudah ada |
| 496 | 122.03 | ~127.1 | ~5.1 s | direktori sudah ada |

Pembacaan hati-hati (inferensi stempel waktu, BUKAN pesan panic):
- Dua abort pertama terjadi sebelum direktori kerja keystore2 (`/data/misc/keystore`, lihat `keystore2.rc`) ada. Itu bisa menjelaskan dua instance itu saja.
- Tiga instance terakhir hidup 4-5,5 s dengan direktori sudah ada, lalu tetap abort. Pola umur seragam lebih cocok dengan penantian/timeout daripada kegagalan file langsung. Ini menambah bobot H2 tetapi bukan bukti.
- Angka "~5 s timeout" tidak diverifikasi ke source keystore2 Android 16. Jangan dijadikan fakta.
- Catatan: keystore2 distart di 78.76 saat /data belum ada. Itu urutan bawaan `class early_hal`, bukan bug patch.

### 2.2 Kenapa penangkap logcat v8 tidak menghasilkan apa pun (dan satu koreksi penting)
Tidak ada baris `starting service 'qemu-logcat'` dan tidak ada `Command 'restorecon_recursive /data' ... (init.target.rc...)` di log v8.

Penyebab yang paling didukung log: `vdc keymaster earlyBootEnded` (init.rc:906, di dalam `on post-fs-data`) NYANGKUT, dan itu menahan seluruh antrean aksi init.
- Di v6 dan v8, setiap `exec` init lain punya baris `Service 'exec N (...)' exited with status X` beberapa detik setelah `SVC_EXEC ... started; waiting...` (mis. exec 4 markBootAttempt, exec 6 prepareCheckpoint). `exec 7 (vdc keymaster earlyBootEnded)` hanya punya baris `started; waiting...` (v6: 100.92 s, v8: 106.87 s) dan tidak pernah punya baris exit sampai reboot paksa (v6 ~123 s, v8 ~131 s). Log vdc itu sendiri berhenti di `Waited 0ms for vold`.
- Baris `Command 'exec ... earlyBootEnded' ... succeeded` hanya berarti proses vdc berhasil di-spawn. Selama sebuah `exec` menunggu, init tidak menjalankan perintah berikutnya di antrean aksi (dari ingatan terhadap source init AOSP, belum dicocokkan ke Android 16). Konsisten dengan log: sesudah 106.87 tidak ada satu pun `starting service` dari perintah post-fs-data berikutnya (mis. `start apexd`) dan tidak ada `start logd ... already running`, dan blok `on post-fs-data` milik vendor (diantre sesudahnya) tidak pernah jalan.
- Servicemanager mencatat langsung siapa yang menunggu: `Caller(pid=280,uid=0,sid=u:r:vold:s0) Since 'android.security.maintenance' could not be found trying to start it as a lazy AIDL service` (v6 102.90 s, v8 108.91 s), sekitar 0,25 s setelah vdc itu mulai. Jadi vold menunggu layanan maintenance keystore2 yang tidak pernah terdaftar karena keystore2 crash terus. Bahwa penantian itu yang menahan vdc tetap inferensi (tidak ada baris yang menyatakannya), tetapi pemanggil dan waktunya cocok.

Koreksi: pernyataan di analisis AI sebelumnya, "vdc keymaster earlyBootEnded sukses di 100.92" (v6), keliru. "succeeded" hanya spawn. Jangan dipakai sebagai bukti bahwa jalur keystore2/HAL sehat.

Akibat praktis: selama keystore2 mati, `on post-fs-data` tidak akan melewati init.rc:906. Hook apa pun yang ditaruh di `post-fs-data` (atau sesudahnya) tidak akan jalan. Aksi `on init` milik vendor TERBUKTI jalan (`processing action (init) from (init.target.rc:677)` di 56.79 s), dan `logd` hidup sejak 52.38 s, jauh sebelum keystore2 (78.76 s).

### 2.3 v9: builder sudah ditulis (belum dijalankan)
File `make_qemu_vendor_modprobe_patch_v9.py` (dikirim bersama addendum) adalah builder v8 dengan perubahan minimal; patch fstab, file_contexts, vendor_modprobe.sh, ramdisk, EROFS, dan QCOW2 tidak diubah. Yang berubah hanya payload tambahan `init.target.rc`:

```
# QEMU-only diagnostics v9: stream logcat to the serial console before keystore2 starts. No policy change.
on init
    start qemu-logcat

service qemu-logcat /system/bin/logcat -b all -v threadtime
    class late_start
    user root
    group log
    console
    disabled
    oneshot
```
- Dihapus dari v8: `setprop init.svc_debug.no_fatal...` (terbukti ditolak SELinux) dan `on post-fs-data` + `restorecon_recursive /data` (tidak pernah jalan, dan stok sudah menjalankan restorecon sendiri).
- Nama berkas keluaran di default builder diganti `-v8` -> `-v9`; builder tetap menolak menimpa keluaran yang sudah ada.
- Yang SUDAH dites di sini (hanya logika payload, terhadap `init.target.rc.original` dari ZIP): payload valid, +285 byte (v8: +356), tetap 8 blok EROFS seperti v8, penjaga anti-duplikat bekerja, dan file asli tidak memuat `qemu-logcat`. Skrip lolos kompilasi.
- Yang TIDAK bisa dites di sini: seluruh pembuatan image (butuh `asgard.formats.erofs`, `qemu-io`, image vendor/super/disk dasar). Letakkan builder di folder yang sama dengan builder v8 asli (supaya `PROJECT` terhitung sama), jalankan, dan baca keluaran validasinya apa adanya.
- Belum diketahui: apakah `qemu-logcat` bisa distart (domain SELinux hasil transisi untuk `/system/bin/logcat` dari init tidak bisa diverifikasi tanpa policy firmware), dan apakah opsi `console` mengalirkan keluaran ke serial. Policy tidak dilonggarkan untuk memaksanya.
- Satu perubahan, satu hipotesis ("logcat bisa ditangkap lewat jalur `on init`"), maksimal 2 percobaan.

Cara membaca log v9 (simpan MENTAH):
1. Cari `starting service 'qemu-logcat'`. Kalau ada pesan gagal dari init atau baris `avc: denied` terkait `logcat`/`console`, salin persis ke NOTES.md sebagai data. Jangan didobrak.
2. Kalau logcat tersambung, cari tag `keystore2`/`KeyMint`/`libc`/`DEBUG` di sekitar 78-130 s. Target pesan: `Failed to open database for Keystore` (H1) vs `Failed to create service ... IKeystoreService` / `does device have /default KeyMint` (H2).
3. Jika tidak ada output serial dan tidak ada penolakan yang menjelaskannya, berhenti dan lapor ke user. Cadangan seperti service `console` stok (`seclabel u:r:shell:s0`) menambah akses shell di guest dan perlu persetujuan user dulu (handoff utama bagian 6B).

## 3. Yang masih belum diketahui (jangan diklaim)
- Pesan panic keystore2 (H1 vs H2) belum ditangkap.
- Apakah `vendor.keymint-qti` (pid 274) menunggu TrustZone: tidak ada baris yang menyatakan itu langsung.
- Di mana `IKeyMintDevice/default`, `IBootControl/default`, `IQSEECom/default` dideklarasikan. Manifest yang sudah diekstrak tidak memuatnya (dicek ulang dengan grep di `extracted/vendor/etc`; hanya `vendor_file_contexts` menyebut qseecom). Perlu Tugas A.
- Apakah `ro.vendor.qti.soc_name` yang kosong mempengaruhi pemuatan manifest.

## 4. Tugas A
Skrip `extract_task_a.py` hanya MENDETEKSI tipe filesystem (magic bytes); ekstraksi berkas dilakukan pelaksana dengan alat yang cocok. Berkas target: `/vendor/etc/vintf/manifest.xml`, seluruh `/vendor/etc/vintf/manifest/`, `/odm/etc/vintf/*`, `/vendor/bin/init.qti.qcv.sh`, `/vendor/etc/init/qseecomd.rc`, `/vendor/etc/init/init.qti.qcv.rc`. Magic yang relevan: EROFS `0xE0F5E1E2` di offset 1024, ext4 `0xEF53` di offset 1080, F2FS `0xF2F52010` di offset 1024, sparse `0xED26FF3A` di offset 0 (perlu `simg2img` dulu).

## 5. Urutan kerja
1. Tugas A, kirim ZIP < 25 MB.
2. v9 = jalankan `make_qemu_vendor_modprobe_patch_v9.py` (bagian 2.3), jalankan QEMU, simpan log serial mentah. Timeout minimal 1800 s seperti handoff utama.
3. Setelah pesan panic ada, baru Tugas C. Batas keselamatan dan kriteria berhenti di handoff utama tidak berubah.
4. Ingat bagian 2.2: selama keystore2 mati, boot berhenti di init.rc:906. Setiap perbaikan keystore2 yang berhasil akan langsung membuka tahap berikutnya (apexd dan seterusnya), jadi baca log tahap itu dengan teliti sebelum menyimpulkan.
