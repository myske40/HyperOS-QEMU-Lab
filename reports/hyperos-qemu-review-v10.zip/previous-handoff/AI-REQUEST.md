# Permintaan diagnosis dan solusi: port HyperOS POCO F6 ke QEMU

Tolong jawab dalam Bahasa Indonesia. Saya sedang menguji porting firmware HyperOS POCO F6 ke virtualisasi QEMU AArch64 virt di laptop Windows. Tujuannya membuat ROM berjalan stabil sebagai guest QEMU; ini bukan fork Android dan bukan percobaan flash ke ponsel.

## Konteks teknis

- ROM: POCO F6 (peridot), HyperOS OS3.0.304.0.WNPIDXM.
- System image Android 16; vendor image Android 14.
- Kernel firmware stok: Linux 6.1.138.
- Guest QEMU: AArch64, machine virt, storage virtual 16 GiB melalui NVMe, uji terakhir 2 GiB RAM dan 4 vCPU. Jumlah core bukan batas tetap proyek.
- Host: Windows. Pengukuran saat uji sebelumnya sekitar 7.2 GiB RAM terlihat oleh Windows; spesifikasi CPU/GPU host belum dikumpulkan.
- Firmware arsip sekitar 8 GiB tersedia di project lokal, tetapi tidak disertakan di ZIP ini.
- Device tree QEMU khusus telah disesuaikan untuk jalur PCIe/NVMe yang diharapkan init POCO.

## Yang sudah terbukti

1. Kernel stok boot di mesin QEMU virt; init tahap pertama dan kedua berjalan.
2. Partisi logical utama dari super berhasil di-mount. AVB/dm-verity dipertahankan untuk partisi selain pengecualian vendor yang sangat terbatas di ramdisk uji.
3. Patch v6 hanya untuk lingkungan uji QEMU:
   - Mengubah /vendor/bin/vendor_modprobe.sh menjadi readiness shim agar init tidak menunggu modul Qualcomm yang tidak tersedia di QEMU.
   - Menghapus opsi enkripsi hardware dan jalur UFS dari dua baris /data di salinan /vendor/etc/fstab.qcom.
   - Menambahkan konteks SELinux khusus untuk tiga node NVMe guest: metadata nvme0n1p6, misc nvme0n1p11, userdata nvme0n1p18.
   - Mengubah dua inode EROFS terkompresi menjadi flat/plain tanpa merekompres LZ4, memakai area nol yang diverifikasi di tail partisi vendor, lalu memperbarui ukuran blocks dan CRC32C EROFS.
   - Menghapus avb=vbmeta hanya dari baris /vendor pada fstab ramdisk uji karena isi vendor diubah. Sepuluh baris AVB lain tetap.
4. Di run terakhir, make_f2fs berhasil memformat userdata dan fs_mgr berhasil memasang /data sebagai F2FS. post-fs-data mulai berjalan.
5. Sesudah itu, proses kritis keystore2 abort empat kali dan init memaksa reboot ke bootloader. Log serial belum menunjukkan Zygote, System Server, sys.boot_completed, atau UI.
6. Log menunjukkan root filesystem /data masih terlihat berlabel SELinux unlabeled pada audit denial. ROM init.rc memang memiliki restorecon /data, jadi perlu diteliti kenapa label root tetap demikian.
7. Log menunjukkan service QTI KeyMint dijalankan dan StrongBox mendaftarkan beberapa interface, tetapi penyebab crash keystore2 belum dipastikan. Jangan anggap ketiadaan default KeyMint sebagai penyebab terbukti.

## Pertanyaan dan permintaan solusi

Berdasarkan lampiran manifest, konfigurasi run, dan potongan log:

1. Apa diagnosis paling kuat untuk crash keystore2 dan reboot? Pisahkan bukti langsung dari hipotesis; tunjukkan baris log yang mendukung setiap klaim.
2. Mengapa root /data masih unlabeled setelah format F2FS dan perintah stok restorecon /data? Berikan pemeriksaan berikutnya yang paling kecil dan aman untuk memastikan penyebabnya.
3. Apa langkah QEMU-only paling kecil untuk memberi guest layanan keamanan yang dibutuhkan agar boot berlanjut? Periksa kemungkinan memakai implementasi software KeyMint/komponen AOSP yang nyata bila cocok dengan versi Android/vendor. Jangan mengarang HAL/library atau menonaktifkan proteksi keamanan secara luas.
4. Apakah kernel stok 6.1.138 cukup untuk perangkat QEMU virt yang sudah teramati, atau perlu kernel ARM64 alternatif? Bedakan kebutuhan driver QEMU (NVMe/PCI/GIC/PL011/virtio) dari kebutuhan HAL proprietary POCO.
5. Susun urutan eksperimen lanjutan yang konkret: file yang diubah pada salinan QEMU, validasi sebelum boot, log yang harus muncul bila berhasil, dan kriteria berhenti bila tidak layak.
6. Jika Anda menyarankan patch, tulis perubahan spesifik atau pseudocode yang bisa langsung ditinjau. Prioritaskan boot stabil ke framework; jangan klaim boot berhasil sebelum ada bukti Zygote/System Server atau sys.boot_completed.

## Batas keselamatan dan integritas

- Jangan menyarankan flash ke perangkat fisik, membuka bootloader perangkat fisik, atau mengubah firmware bootloader.
- Jangan menyarankan menonaktifkan AVB/dm-verity/SELinux secara global atau memasang SELinux permissive.
- Jangan membuat-buat driver, library, atau HAL Qualcomm.
- Semua perubahan harus terbatas pada image/overlay turunan QEMU. Source firmware dan disk dasar harus tetap read-only.
- Jelaskan konsekuensi keamanan setiap pengecualian yang benar-benar diperlukan.

## Lampiran

- qemu-v6-patch-manifest.json: lokasi, alasan, hash, dan validasi patch v6.
- qemu-v6-run-config.json: parameter run QEMU terakhir.
- qemu-v6-log-excerpt.txt: baris serial yang relevan untuk format/mount /data, label SELinux, dan crash keystore2.
