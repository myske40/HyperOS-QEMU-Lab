# HyperOS QEMU Lab — POCO F6 / peridot

**Status per 5 November 2026:** Android belum boot sampai framework. Kernel stok 6.1.138, init Android, partisi dinamis dari `super`, NVMe virtual, dan `/data` sudah dicapai dalam sejumlah run. Run v10 berakhir dengan reboot karena lima abort `keystore2`; layanan diagnostik yang diharapkan untuk mengambil panic tidak sempat berjalan. Belum ada bukti Zygote, System Server, `sys.boot_completed`, atau UI.

Folder ini berisi aplikasi analisis native Windows dan toolkit QEMU. Tujuan akhir adalah menguji HyperOS POCO F6 di QEMU AArch64 `virt` dengan disk virtual 16 GiB dan RAM target awal 4 GiB. QEMU `virt` tidak meniru SoC Qualcomm POCO; firmware ARM64 saja tidak menjamin kompatibilitas.

## Riwayat percakapan dan keputusan

Bagian ini merangkum dari permintaan pertama sampai run terakhir, termasuk koreksi ruang lingkup, masukan AI peninjau, dan batas yang ditetapkan pengguna. Ini ringkasan kronologis, bukan salinan verbatim setiap pesan. Selingan obrolan yang tidak mengubah proyek tidak dicatat sebagai keputusan teknis.

1. **Permintaan awal:** analisis firmware HyperOS ARM64 dan kelayakan boot di QEMU AArch64 `virt`. Ruang lingkup meliputi format image, kernel, ramdisk, fstab, DTB, layout partisi, dependensi hardware, layanan init, modifikasi yang dibutuhkan, konfigurasi QEMU, validasi dan log. Sumber firmware harus tetap utuh; tidak boleh flash atau mengubah perangkat Xiaomi fisik, membabi buta menonaktifkan AVB/dm-verity/SELinux, atau membuat driver/pustaka vendor palsu.
2. **Platform dan firmware:** pengguna meminta jawaban Bahasa Indonesia, proyek berjalan native di Windows, dan firmware diunduh manual ke laptop. Model diklarifikasi sebagai POCO F6 (`peridot`) dengan ROM Indonesia `OS3.0.304.0.WNPIDXM`. Pengguna sempat meminta tautan unduhan alternatif karena unduhan resmi sangat lambat, lalu mengabarkan arsip sekitar 8 GiB selesai diunduh.
3. **Tujuan virtualisasi diperjelas:** eksperimen dilakukan di QEMU pada laptop, bukan pada ponsel. Koreksi lisan “BOOT.IMG” lalu diperjelas menjadi adaptasi/porting ROM Android untuk virtualisasi QEMU, bukan fork atau port untuk perangkat fisik. Jumlah core bukan batas tetap proyek. Pengguna ingin QEMU dicoba, dianalisis, dan dioptimalkan; root/Magisk/UBL disebut sebagai keinginan lanjutan, tetapi belum dikerjakan karena Android belum boot. Tidak ada rencana membuka bootloader atau memasang Magisk pada POCO fisik.
4. **Proyek Windows dan kemajuan awal:** dibuat aplikasi desktop lokal (`app.py`, Tkinter; `run.bat`) serta skrip analisis dan QEMU. Tahap awal mengatasi `exit 127`, kernel/ramdisk, jalur NVMe, dan init. DTB virtual turunan menyesuaikan jalur PCIe ke asumsi init POCO. Kernel stok dapat berjalan di `virt`; init mencapai pemasangan logical partition dari `super` dengan AVB tetap aktif.
5. **AI peninjau:** pengguna meminta konteks, pertanyaan, dan saran dalam Markdown/ZIP kecil untuk Claude. Beberapa jawaban dan addendum peninjau dimasukkan ke paket handoff. Hasil review memperbaiki asumsi tentang log keystore2: panic hook hanya dipastikan lewat logcat dari source lama; pesan H1 (database/label `/data`) dan H2 (KeyMint) harus dibedakan dari bukti log. Review juga meluruskan bahwa AOSP `system/keymint` adalah library, bukan service pengganti QTI yang tinggal ditimpa.
6. **Aturan diagnosis yang disepakati:** satu hipotesis/perubahan per run; simpan serial mentah lengkap; denial SELinux adalah bukti dan tidak boleh “ditembus”; tidak mengubah `no-fatal`, policy SELinux, AVB atau dm-verity untuk memaksa diagnosis; jangan mengganti KeyMint sebelum ada bukti; jangan mengklaim boot sebelum Zygote/System Server atau `sys.boot_completed`. Image sumber dan disk dasar read-only; eksperimen hanya melalui image/overlay turunan.
7. **Operasi dan jeda:** pengguna bertanya tentang progres/live QEMU dan meminta proses bisa dihentikan ketika cuaca petir lalu dilanjutkan kemudian. Pengguna kemudian meminta pekerjaan dilanjutkan serta meminta laporan kejujuran apakah Android sudah masuk kernel/framework. Jawabannya tetap: kernel/init tercapai, framework belum.
8. **Permintaan paket peninjau:** pengguna meminta ZIP kecil di bawah 25 MB berisi serial mentah v6–v8, skrip/RC patch, konfigurasi dan hash, ekstrak teks konfigurasi firmware, kernel config, NOTES, dan checksum. Paket reviewer-ready v6–v9 dibuat dan disimpan di `reports/hyperos-qemu-review-v9-taskA-reviewer-ready.zip` (556.223 byte; SHA-256 `8bdc9906de637a8d7961d8ec5771e9d47466377b219d40135fd041d17c52f02e`). Firmware, super/partisi, disk, CPIO dan binary proprietary tidak disertakan.
9. **Klarifikasi label dan layanan:** byte akhir `vendor_file_contexts` adalah newline (`0a`), jadi dugaan baris menempel gugur. Restorecon bawaan `/data` belum terbukti berhasil hanya dari urutan waktu. VINTF menyatakan KeyMint, BootControl dan QSEECom, tetapi deklarasi tidak membuktikan layanan berjalan di QEMU. Layanan proprietary tanpa perangkat SoC tetap hambatan.
10. **Run v6:** penggantian `vendor_modprobe.sh`, label NVMe untuk partisi placeholder, dan fstab turunan memungkinkan format/mount `/data` F2FS serta `post-fs-data`. `keystore2` berulang kali SIGABRT lalu init reboot. Tidak ada bukti boot framework.
11. **Run v7:** trigger properti privat `init.svc.keystore2` ditolak policy (`init_service_status_private_prop`); percobaan itu gugur.
12. **Run v8:** pengaturan `init.svc_debug.no_fatal.keystore2` dari `vendor_init` ditolak policy (`default_prop`). Tidak dilakukan perubahan policy. Hook logcat di `post-fs-data` tidak tercatat berjalan; timing restorecon tidak cukup untuk menyimpulkan keberhasilan.
13. **Run v9:** hanya cara pengambilan logcat yang diubah, dipindah ke `on init`. Init mendapat denial SELinux `{ getattr }` pada `/system/bin/logcat` (`scontext=u:r:init:s0`, `tcontext=u:object_r:logcat_exec:s0`). Tidak ada pelonggaran policy. Guest reboot setelah lima abort `keystore2`; panic tetap tidak tertangkap.
14. **Run v10:** berdasarkan pembacaan policy CIL, domain `shell` sudah memiliki izin menjalankan `logcat`, membaca socket logd, dan memakai console. Dibuat satu layanan diagnostik one-shot berlabel `u:r:shell:s0`, tanpa perubahan policy, untuk menulis logcat/tombstone ke console serial dan menjalankan `restorecon -n` (dry-run). Layanan dipicu oleh `post-fs-data`. QEMU menyelesaikan run, tetapi layanan tidak muncul di log serial sebelum reboot; karena itu cara ini belum berhasil mengumpulkan panic. Lima abort `keystore2` kembali terjadi. Tidak ada percobaan QEMU lanjutan setelah run v10.
15. **Permintaan terbaru:** jika diagnosis v10 gagal, pengguna meminta proyek dihapus, tetapi sebelumnya semua yang dilakukan, masalah dan alasan berhenti harus didorong ke GitHub akun `myske40`. Pengguna juga meminta README ini merangkum seluruh riwayat chat dan meminta pekerjaan dihentikan setelah run QEMU selesai karena ada proyek lain. Run selesai; penghapusan belum dilakukan karena folder belum punya remote Git dan tidak ada tujuan repo terpilih. Penghapusan menunggu push yang diminta.

## Firmware dan host

- Perangkat target ROM: POCO F6, codename `peridot`; paket Indonesia HyperOS `OS3.0.304.0.WNPIDXM`.
- System image Android 16/API 36; vendor image Android 14/API 34.
- Kernel ARM64 stok Linux `6.1.138-android14-11-g0c3d559bcd85-ab14529422`.
- Konfigurasi kernel hasil ekstrak `IKCFG_ST` tersedia di `analysis/kernel.config`. Kernel mengaktifkan PL011 console, GICv3, PSCI, PCI generic, NVMe, EROFS dan F2FS; opsi virtio block tidak aktif. Karena itu percobaan storage memakai NVMe virtual.
- `super.img` berupa Android sparse; logical `system_a` dan `vendor_a` EROFS. Metadata partisi logis serta file teks Task A ada di `analysis`.
- Host Windows terdeteksi memiliki sekitar 7,2 GiB RAM. Run v10 memakai 3 GiB guest untuk mengurangi risiko tekanan memori, 4 vCPU, CPU `max,pauth-impdef=on`, mesin `virt`, disk virtual 16 GiB, timeout 1800 detik, dan DTB virtual POCO turunan. Saat persiapan host melaporkan sekitar 1,1 GiB RAM bebas.

## Riwayat teknis eksperimen

| Versi | Perubahan pokok | Hasil |
|---|---|---|
| Sebelum v6 | Penyesuaian kernel/ramdisk/DTB QEMU; mengatasi `exit 127`, Gunyah, dan jalur NVMe. | Kernel dan init berjalan; logical partitions termount dengan AVB; belum framework. |
| v6 | File-context NVMe, fstab `/data` tanpa ketergantungan enkripsi/UFS, dan no-op `vendor_modprobe.sh` untuk QEMU. | `/data` F2FS termount; `keystore2` abort lima kali dan init reboot. |
| v7 | Diagnosis memakai trigger status layanan privat. | SELinux menolak akses property; metode dibatalkan. |
| v8 | Diagnosis no-fatal dan pengambilan log setelah `post-fs-data`. | SELinux menolak property no-fatal; hook tidak terbukti berjalan. |
| v9 | Mulai logcat dari `on init` dalam domain init. | SELinux menolak akses `/system/bin/logcat`; tidak ada log panic. |
| v10 | One-shot shell-domain service untuk logcat/tombstone dan inspeksi label; tanpa perubahan SELinux. | Trigger tidak tercatat berjalan; guest reboot setelah lima abort. |

## Run v10 dan bukti

- Konfigurasi: `virt`, 3 GiB, 4 vCPU, `max,pauth-impdef=on`, disk 16 GiB, timeout 1800 s.
- Durasi proyek sampai run v10 berakhir: rentang timestamp thread Codex dari 5 Nov 2026 09:37:13 WIB sampai selesai QEMU sekitar 20:27:14 WIB, yaitu kira-kira **10 jam 50 menit elapsed**. Ini termasuk jeda, menunggu, dan run sebelumnya; bukan klaim 10 jam kerja aktif. Pengguna sebelumnya menyebut sekitar 5 jam 25 menit pada tahap lebih awal.
- Durasi proses run QEMU v10: sekitar **4 menit 31 detik** waktu host (270,6 s); uptime guest sampai reboot sekitar 266,3 s.
- QEMU process exit `0`, sebelum batas waktu (`stopped_by_timeout=false`). Ini hanya berarti proses emulasi berhenti normal saat guest meminta reboot; **bukan** keberhasilan Android.
- Serial mentah penuh: `analysis/qemu-avb-20261105-202244.serial.log`, 333.506 byte, SHA-256 `E69A9B72FA0A7ED776607B50D3D9F3AF246A47EB12A98362541F832E11C3BC80`.
- Metadata run: `analysis/qemu-avb-20261105-202244.json`.
- Abort `keystore2`: uptime guest 217.826, 229.671, 244.269, 254.554, dan 265.038 s; init melaporkan critical process keluar empat kali pada 265.092 s dan guest reboot ke bootloader pada 266.266 s.
- Tidak ada marker `QEMU-logcat-begin`, `QEMU-diagnostics-end`, `restorecon-dry-run`, atau `tombstones-begin`; tidak ada pesan panic `Failed to open database for Keystore` maupun `Failed to create service ... IKeystoreService`.
- AVC serial menunjukkan layanan `hypsys_ssi_default` mencari direktori root userdata dengan target `u:object_r:unlabeled:s0`. Ini bukti bahwa setidaknya pada saat AVC, root `/data` masih dilihat sebagai unlabeled; ini **belum membuktikan** bahwa itulah penyebab abort keystore2. Catatan stock `restorecon /data` tidak memberikan baris sukses eksplisit di serial v10.
- Di sekitar post-fs-data, init menjalankan `/system/bin/vdc keymaster earlyBootEnded`; serial menunjukkan service exec mulai dan kemudian log `vdc()++`/`Waited 0ms for vold`. Setelah itu layanan diagnostik v10 tidak tercatat dimulai sebelum reboot. Hubungan antrean init dengan gagalnya trigger adalah hipotesis yang didukung urutan log, bukan bukti source-code bahwa perintah `vdc` penyebab tunggal.
- Tidak ada Zygote, System Server, `sys.boot_completed`, atau UI. Root/Magisk belum diuji.

## File dan laporan penting

- [Analisis firmware awal](reports/firmware-analysis-initial.md)
- [Perkembangan boot sebelumnya](reports/boot-progress-2026-11-05.md)
- [Catatan eksperimen dan bukti terbaru](reports/NOTES.md)
- [Paket review v6–v9](reports/hyperos-qemu-review-v9-taskA-reviewer-ready.zip)
- [Builder v10](tools/make_qemu_vendor_modprobe_patch_v10.py)
- [Serial mentah v10](analysis/qemu-avb-20261105-202244.serial.log)
- [Konfigurasi run v10](analysis/qemu-avb-20261105-202244.json)

## GitHub dan penghapusan

Pengguna meminta commit/push laporan sebelum folder proyek dihapus jika diagnosis gagal. Folder `D:\git\HyperOS-QEMU-Lab` saat ini **bukan** repository Git dan tidak memiliki remote. Akun `myske40` mempunyai repository publik bernama `Laptopstatus`, yang tidak terkait dengan proyek ini; tidak ada repository proyek yang dipilih. GitHub CLI tidak tersedia. Belum ada file yang di-push dan belum ada folder yang dihapus. Jangan menghapus project sebelum ada repo tujuan yang sesuai dan push diverifikasi.

## Menjalankan aplikasi

Klik dua kali `run.bat`, atau dari PowerShell:

```powershell
py -3 app.py
```

Aplikasi berjalan lokal tanpa server. Ia menginventarisasi nama/ukuran, membaca signature format dan menghitung SHA-256; laporan Markdown disimpan pada lokasi yang dipilih pengguna. Analisis mendalam dan QEMU dijalankan melalui alat dalam `tools`.

## Integritas dan batas kerja

- Arsip dan partisi firmware sumber hanya dibaca. Disk dasar 16 GiB tidak ditulis oleh run; setiap boot memakai QCOW2 overlay terpisah.
- Tidak ada flash ke ponsel, perubahan bootloader fisik, atau instalasi Magisk.
- AVB/dm-verity tetap aktif kecuali pengecualian AVB terbatas pada `/vendor` dalam ramdisk **turunan QEMU** karena isi vendor overlay berubah. AVB lainnya tidak dibuang. SELinux tetap enforcing; tidak ada policy yang dilonggarkan.
- Tidak ada driver, HAL, atau library Qualcomm/NXP palsu yang dibuat.
- Untuk melanjutkan di masa depan, mulai dari kegagalan v10: trigger diagnostik `post-fs-data` tidak tercapai sebelum reboot. Jangan ulangi hook logcat domain-init v9 atau trigger no-fatal/private-property v7–v8. Firmware sumber dan disk dasar harus tetap read-only.

