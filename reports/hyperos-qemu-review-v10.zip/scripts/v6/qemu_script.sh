#! /vendor/bin/sh
# QEMU has no POCO F6 kernel modules.
setprop vendor.all.modules.ready 1
exit 0
